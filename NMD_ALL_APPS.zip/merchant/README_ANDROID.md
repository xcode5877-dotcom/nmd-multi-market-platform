# Now Merchant – Android Project

Standalone Android project for the **Merchant** app (com.nmd.merchant). Loads `https://nmd.marketing/merchant` in a WebView and sets the User-Agent so the web app’s `isNativeApp` logic works.

## Config (already applied)

- **appId:** `com.nmd.merchant`
- **appName:** Now Merchant
- **server.url:** https://nmd.marketing/merchant
- **capacitor.config.json:** in parent folder `../capacitor.config.json`

## WebView User-Agent (isNativeApp)

The WebView User-Agent is set so the web app detects the native shell:

1. **In code:** `MainActivity.java` gets the default User-Agent and appends the suffix from `res/values/strings.xml`:
   - `webview_user_agent_suffix` = `" NMD-Native-App"`.
   - Result: `defaultUa + " NMD-Native-App"`, so `navigator.userAgent.includes('NMD-Native-App')` is true and `isNativeApp` activates.

2. **Snippet (already in MainActivity):**
   ```java
   String defaultUa = settings.getUserAgentString();
   String suffix = getString(R.string.webview_user_agent_suffix); // " NMD-Native-App"
   settings.setUserAgentString(defaultUa + suffix);
   ```

No extra steps are required for User-Agent; it’s set at runtime in `MainActivity`.

## Asset integration (already done)

Assets from the parent `merchant/` folder are already mapped:

| Source (merchant folder) | Android path |
|--------------------------|--------------|
| `icon.png`               | `app/src/main/res/mipmap-xxxhdpi/ic_launcher.png` and `ic_launcher_round.png` |
| `splash.png`             | `app/src/main/res/drawable/splash.png` |

To refresh after changing assets in `../`:

```bash
cp ../icon.png app/src/main/res/mipmap-xxxhdpi/ic_launcher.png
cp ../icon.png app/src/main/res/mipmap-xxxhdpi/ic_launcher_round.png
cp ../splash.png app/src/main/res/drawable/splash.png
```

Optional: add `mipmap-hdpi`, `mipmap-mdpi`, `mipmap-xhdpi`, `mipmap-xxhdpi` with scaled icons for better quality on all devices.

## How to build the APK

### Option 1: Android Studio (recommended)

1. Open Android Studio.
2. **File → Open** and select this folder (`android-project`).
3. Wait for Gradle sync (Android Studio may download SDK components and create the Gradle wrapper).
4. **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. APK path: `app/build/outputs/apk/debug/app-debug.apk` (or `release` if you built a release variant).

For a signed release APK:

- **Build → Generate Signed Bundle / APK → APK** and follow the wizard.

### Option 2: Command line (after Gradle wrapper exists)

If the project already has a Gradle wrapper (e.g. after opening once in Android Studio):

```bash
cd apps/native-assets/merchant/android-project
./gradlew assembleDebug
# Output: app/build/outputs/apk/debug/app-debug.apk
```

Release (unsigned):

```bash
./gradlew assembleRelease
# Output: app/build/outputs/apk/release/app-release-unsigned.apk
```

To get the wrapper on a machine that has Android Studio / SDK:

- Open the project in Android Studio once so it creates `gradlew` and `gradle/wrapper/`, or
- Run `gradle wrapper` from the project root if Gradle is installed.

### Option 3: Copy project to your PC

1. Zip this folder: `apps/native-assets/merchant/android-project`.
2. Copy the zip to your PC, unzip, and open the folder in Android Studio.
3. Then use **Option 1** to build the APK.

## Summary

- **appId:** com.nmd.merchant  
- **WebView URL:** https://nmd.marketing/merchant  
- **User-Agent:** Default UA + `" NMD-Native-App"` (set in `MainActivity.java`).  
- **Icons/splash:** Mapped from `../icon.png` and `../splash.png`; refresh with the `cp` commands above if you change them.  
- **APK:** Open in Android Studio → Build APK(s), or use `./gradlew assembleDebug` / `assembleRelease` when the wrapper is present.
