# Now Customer – Android Project

Standalone Android project for the **Customer** app (com.nmd.customer). Loads `https://nmd.marketing` in a WebView and sets the User-Agent so the web app’s `isNativeApp` logic works.

## Config

- **appId:** com.nmd.customer
- **appName:** Now Customer
- **server.url:** https://nmd.marketing
- **Gradle:** 8.2 (gradle-wrapper.properties)
- **AGP:** 8.2.0 (build.gradle)

## WebView User-Agent

MainActivity appends ` NMD-Native-App` to the default User-Agent so `navigator.userAgent.includes('NMD-Native-App')` is true and the web app’s native UI (hide A2HS, fixed checkout, push) activates.

## Assets

- **icon:** from `../icon.png` → `res/mipmap-xxxhdpi/ic_launcher.png` and `ic_launcher_round.png`
- **splash:** from `../splash.png` → `res/drawable/splash.png`

## Build APK

**Android Studio:** Open this folder → Build → Build Bundle(s) / APK(s) → Build APK(s).

**CLI:** `./gradlew assembleDebug` (output: `app/build/outputs/apk/debug/app-debug.apk`).
