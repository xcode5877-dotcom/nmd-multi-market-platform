# Keep WebView and app entry
-keep class com.nmd.customer.MainActivity { *; }
