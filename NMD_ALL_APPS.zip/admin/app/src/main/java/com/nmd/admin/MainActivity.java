package com.nmd.admin;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Now Admin – WebView shell. Loads https://nmd.marketing/admin
 * and sets User-Agent to include "NMD-Native-App" so the web app's
 * isNativeApp logic activates (NativeBridgeContext).
 */
public class MainActivity extends AppCompatActivity {

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WebView webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);

        String defaultUa = settings.getUserAgentString();
        String suffix = getString(R.string.webview_user_agent_suffix);
        settings.setUserAgentString(defaultUa + suffix);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url != null && (url.startsWith("https://nmd.marketing") || url.startsWith("http://"))) {
                    view.loadUrl(url);
                    return true;
                }
                return false;
            }
        });

        webView.loadUrl(getString(R.string.webview_url));
    }
}
