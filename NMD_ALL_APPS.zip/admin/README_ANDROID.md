# Now Admin – Android Project

Standalone Android project for the **Admin** app (com.nmd.admin). Loads `https://nmd.marketing/admin` in a WebView with User-Agent suffix `NMD-Native-App`.

- **appId:** com.nmd.admin | **Gradle:** 8.2 | **AGP:** 8.2.0
- **Build:** Open in Android Studio or run `./gradlew assembleDebug`
