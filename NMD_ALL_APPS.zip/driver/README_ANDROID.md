# Now Driver – Android Project

Standalone Android project for the **Driver** app (com.nmd.driver). Loads `https://nmd.marketing/driver` in a WebView with User-Agent suffix `NMD-Native-App`.

- **appId:** com.nmd.driver | **Gradle:** 8.2 | **AGP:** 8.2.0
- **Build:** Open in Android Studio or run `./gradlew assembleDebug`
